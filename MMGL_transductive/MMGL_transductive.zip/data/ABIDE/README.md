### Data preprcessing of ABIDE dataset
First, you need to run the 'data_processing.ipynb' to obtain the preprocessed features from fMRI.
Then, run the 'phenotyic_processing.ipynb' to extract the phenotyic feature and obtain the final preprocessed multi-modal dataset.

###Acknowledgement 
The most of code of 'data_processing.ipynb' is borrowed from PopGCN [https://github.com/parisots/population-gcn], thanks a lot for the contribution to the community!
