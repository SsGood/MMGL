python main.py --GC_mode weighted-cosine --MF_mode concat --MP_mode GCN --datname ABIDE --dropout 0.35 --lr 0.0038 --mode simple-2 --n_head 2 --n_hidden 18 --nlayer 1 --reg 0.11
