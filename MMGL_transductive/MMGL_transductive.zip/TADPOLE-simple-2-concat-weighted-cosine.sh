python main.py --GC_mode weighted-cosine --MF_mode concat --MP_mode GCN --datname TADPOLE --dropout 0 --lr 0.0055 --mode simple-2 --n_head 2 --n_hidden 18 --nlayer 3 --reg 0.26
python main.py --GC_mode weighted-cosine --MF_mode concat --MP_mode GCN --datname TADPOLE --dropout 0 --lr 0.0055 --mode simple-2 --n_head 2 --n_hidden 18 --nlayer 3 --reg 0.26
